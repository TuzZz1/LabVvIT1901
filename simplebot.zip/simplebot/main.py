from random import choice

import telebot
from telebot import types
from glob import glob

token = "5214529452:AAFmzt1jDvLB-C5eR7_rFgd96mmYbph4RDQ"

bot = telebot.TeleBot(token)

keyboard = types.ReplyKeyboardMarkup()
keyboard.row("/mtuci", "/funmem", "/clothes", "/help")


@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, 'Hello! This is first meet with u?'
                     , reply_markup=keyboard)


@bot.message_handler(commands=['help'])
def start_message(message):
    bot.send_message(message.chat.id, 'I can give new info about MTUCI (/mtuci)' + '\n'
                                      'Show u fun picture (/funmem)' + '\n'
                                      'Provide links to website for buying clothes (/clothes)')


@bot.message_handler(commands=['mtuci'])
def start_mtuci(message):
    bot.send_message(message.chat.id, 'Lets - https://mtuci.ru/')


@bot.message_handler(commands=['funmem'])
def start_mem(message):
    keyboardmem = types.ReplyKeyboardMarkup()
    keyboardmem.row("Next", "Back")

    lists = glob('img/*')
    picture = choice(lists)
    bot.send_photo(message.chat.id, photo=open(picture, 'rb'), reply_markup=keyboardmem)


@bot.message_handler(commands=['clothes'])
def start_clothes(message):
    keyboardclothes = types.ReplyKeyboardMarkup()
    keyboardclothes.row("Nike", "Adidas", "Asos", "Supreme", "Back")
    bot.send_message(message.chat.id, "Choose website", reply_markup=keyboardclothes)


@bot.message_handler(content_types=['text'])
def answer(message):

    if message.text.lower() == "nike":
        bot.send_message(message.chat.id, 'https://www.nike.com/ru')
    if message.text.lower() == "adidas":
        bot.send_message(message.chat.id, 'https://www.adidas.ru')
    if message.text.lower() == "asos":
        bot.send_message(message.chat.id, 'https://www.asos.com/ru/')
    if message.text.lower() == "supreme":
        bot.send_message(message.chat.id, 'https://www.supremenewyork.com/')
    if message.text.lower() == "back":
        bot.send_message(message.chat.id, 'Ok', reply_markup=keyboard)
    if message.text.lower() == "next":
        start_mem(message)


bot.polling(none_stop=True, interval=0)
