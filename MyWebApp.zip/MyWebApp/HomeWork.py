import math

a = 4
b = 3
c = 6

discr = 4 * a * c

x_first = (-b + math.sqrt(discr)) / (2 * a)
x_second = (-b - math.sqrt(discr)) / (2 * a)


